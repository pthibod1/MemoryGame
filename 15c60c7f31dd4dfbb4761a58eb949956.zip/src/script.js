// Memory Game built from a version created by NateWiley (2014) on codepen
// Modified by Paul Thibodeau (2020)


//THESES ARE USEFUL
//			console.log(typeof test); //YAY: YOU WANT THIS
//			console.log(Object.getOwnPropertyNames(this))
//			console.log(this.cardsArray)



(function(){
	
	// initializing some variables
	let moves = 0 // a counter
	var mgVersion = '1-codepen';
	var locations = '' //locations of cards
	var turnN = {}; //turn id
	var turnID = {}; //card id chosen at that turn
	var turnLoc = {}; //card location chosen at that turn
	var timeStamp = {}; //timestamp for that turn
	

	var Memory = {

// 		initializes the game; shuffles the cards
		init: function(cards){
			this.$game = $(".game");
			this.$modal = $(".modal");
			this.$overlay = $(".modal-overlay");
			this.$restartButton = $("button.restart");
			this.cardsArray = $.merge(cards, cards);
			this.shuffleCards(this.cardsArray);
			this.setup();
		},


// 		shuffles the cards
		shuffleCards: function(cardsArray){
			this.$cards = $(this.shuffle(this.cardsArray));
		},


// 		starts the game
		setup: function(){
			this.html = this.buildHTML();
			this.$game.html(this.html);
			this.$memoryCards = $(".card");
			this.paused = false;
     	this.guess = null;
			this.binding();			
		},

// instructions for how to handle a "move" in the game
		binding: function(){
			this.$memoryCards.on("click", this.cardClicked);
			this.$restartButton.on("click", $.proxy(this.reset, this));
		},
		
		
		// kinda messy but hey
		cardClicked: function(){			
			moves = moves + 1;			
			var _ = Memory;
			var $card = $(this);
			turnN[moves] = moves //stores move number
			turnID[moves] = $card.attr("data-id") //stores card chosen
			turnLoc[moves] = $card.attr("loc") //stores location chosen
			var date = new Date();
			timeStamp[moves] = date.getTime(); //stores timestamp
			
			
			if(!_.paused && !$card.find(".inside").hasClass("matched") && !$card.find(".inside").hasClass("picked")){
				$card.find(".inside").addClass("picked");
				if(!_.guess){
					_.guess = $(this).attr("data-id");
				} else if(_.guess == $(this).attr("data-id") && !$(this).hasClass("picked")){
					$(".picked").addClass("matched");
					_.guess = null;
				} else {
					_.guess = null;
					_.paused = true;
					setTimeout(function(){
						$(".picked").removeClass("picked");
						Memory.paused = false;
					}, 800);
				}
				if($(".matched").length == $(".card").length){
					_.win();
				}
				
			}
		},

// 		if the game is over
		win: function(){

//			console.log(moves); // keep this counter of moves!
			var completeID = getRandomInt(999999)	
		var turns = {
				n: turnN, 
				id: turnID, 
				loc: turnLoc,
				time: timeStamp,
				compCode: completeID,
				totMoves: moves,
				mgVersion: mgVersion
			}
		//console.log(turns)	
				
		this.saveData(turns)
			
			this.paused = true;
			setTimeout(function(){
				Memory.showModal();
				Memory.$game.fadeOut();
			}, 1000);
		},

// 		box that celebrates the win
		showModal: function(){
			this.$overlay.show();
			this.$modal.fadeIn("slow");
		},

// 		removes the win box
		hideModal: function(){
			this.$overlay.hide();
			this.$modal.hide();
		},

// 		resets the game
		reset: function(){
			this.hideModal();
			this.shuffleCards(this.cardsArray);
			this.setup();
			this.$game.show("slow");
		},

// 		algorithm that does the shuffling
		shuffle: function(array){
			var counter = array.length, temp, index;
			
			//			
	   	// While there are elements in the array
	   	while (counter > 0) {
        	// Pick a random index
        	index = Math.floor(Math.random() * counter);
        	// Decrease counter by 1
        	counter--;
        	// And swap the last element with it
        	temp = array[counter];
        	array[counter] = array[index];
        	array[index] = temp;
	    	}
	    	return array;
		},

		saveData: function(turns){
			const now = new Date();
			
			var idOrd = ''
			var locOrd = ''
			var nOrd = ''
			var timeOrd = ''
			 for (var j = 1; j < moves+1; j++) {
          idOrd += turns.id[j] + ',';
				 locOrd += turns.loc[j] + ',';
				 nOrd += turns.n[j] + ',';
				 timeOrd += turns.time[j] + ',';
       }
				idOrd=idOrd.slice(0,-1)
				locOrd=locOrd.slice(0,-1)
				nOrd=nOrd.slice(0,-1)
				timeOrd=timeOrd.slice(0,-1)
			
			var url = 'https://sheet2api.com/v1/U37G9Dp4Toq0/sheetsutest'; //this is my spreadsheet
			const newRowData = { "Date": now, "VersionKey": turns.mgVersion,  "CompletionCode": turns.compCode, "Moves": turns.totMoves, "TurnsID":nOrd, "CardID":idOrd, "LocationID":locOrd, "TimeID":timeOrd};
			const options = {};
			Sheet2API.write(url, options, newRowData).then(function(result){
			console.log(result);
				}, function(error){
			  console.log(error);
			});
		},
		
		buildHTML: function(){
			var frag = '';
				this.$cards.each(function(k, v){
				frag += '<div class="card" loc="'+(k+1)+'" data-id="'+ v.id +'"><div class="inside">\
				<div class="front"><img src="'+ v.img +'"\
				alt="'+ v.name +'" /></div>\
				<div class="back"><img src="https://openclipart.org/download/254975/SimpleDesign44.svg"\
				alt="Codepen" /></div></div>\
				</div>';				
				locations = locations+ v.id;
			});

			return frag;
			
		}
	};

	var cards = [
		{
			name: "php",
			img: "https://s3-us-west-2.amazonaws.com/s.cdpn.io/74196/php-logo_1.png",
			id: 1,
		},
		{
			name: "css3",
			img: "https://s3-us-west-2.amazonaws.com/s.cdpn.io/74196/css3-logo.png",
			id: 2
		},
		{
			name: "html5",
			img: "https://s3-us-west-2.amazonaws.com/s.cdpn.io/74196/html5-logo.png",
			id: 3
		},
		{
			name: "jquery",
			img: "https://s3-us-west-2.amazonaws.com/s.cdpn.io/74196/jquery-logo.png",
			id: 4
		}, 
		{
			name: "javascript",
			img: "https://s3-us-west-2.amazonaws.com/s.cdpn.io/74196/js-logo.png",
			id: 5
		},
		{
			name: "node",
			img: "https://s3-us-west-2.amazonaws.com/s.cdpn.io/74196/nodejs-logo.png",
			id: 6
		},
		{
			name: "photoshop",
			img: "https://s3-us-west-2.amazonaws.com/s.cdpn.io/74196/photoshop-logo.png",
			id: 7
		},
		{
			name: "python",
			img: "https://s3-us-west-2.amazonaws.com/s.cdpn.io/74196/python-logo.png",
			id: 8
		}
	];
    
function getRandomInt(max) {
  return Math.floor(Math.random() * Math.floor(max));
}

	

	
		Memory.init(cards);
	
})();