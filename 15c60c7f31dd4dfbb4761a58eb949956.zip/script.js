// Memory Game built from a version created by NateWiley (2014) on codepen
// Modified by Paul Thibodeau (2020)

//THESES ARE USEFUL
//			console.log(typeof test); //YAY: YOU WANT THIS
//			console.log(Object.getOwnPropertyNames(this))
//			console.log(this.cardsArray)
(function() {
  //STUFF THAT I ONLY WANT TO DO ONCE:
  var mgVersion = "Prolific-1";
  var stimCondition = "i"; //?999?sh?i?12?3
  var nCards = 8;
  var manip = "lo"; //sh vs: lo
  var nTrials = 3;
  var trialCounter = 1;
  var completeID = getRandomInt(999999999);
  var windowWidth = window.innerWidth;
  var windowHeight = window.innerHeight;

  
  //figure out condition from url
  const url = document.URL;
  checkURL = url.split("?")[1];
  if (parseInt(checkURL) == 999) {
    manip = url.split("?")[2];
    stimCondition = url.split("?")[3];
    nCards = parseInt(url.split("?")[4]);
    nTrials = parseInt(url.split("?")[5]);
  }

  var ipAddress = "999";
  $.getJSON("https://api.ipify.org?format=json", function(data) {
    ipAddress = data.ip;
  });

  let root = document.documentElement;
  switch (nCards) {
    case 8:
      root.style.setProperty("--cardHeight", "25%");
      root.style.setProperty("--cardWidth", "25%");
      break;
    case 10:
      root.style.setProperty("--cardHeight", "25%");
      root.style.setProperty("--cardWidth", "20%");
      break;
    case 12:
      root.style.setProperty("--cardHeight", "25%");
      root.style.setProperty("--cardWidth", "16.66%");
      break;
    case 15:
      root.style.setProperty("--cardHeight", "20%");
      root.style.setProperty("--cardWidth", "16.66%");
      break;
    case 18:
      root.style.setProperty("--cardHeight", "16.66%");
      root.style.setProperty("--cardWidth", "16.66%");
  }

  //THINGS THAT SHOULD BE SET BEFORE A GAME (ie reset if playing multiple games)
  //These could be bundled into a single object
  let moves = 0; // a counter of moves
  var locations = ""; //locations of cards
  var turnN = {}; //turn id
  var turnID = {}; //card id chosen at that turn
  var turnLoc = {}; //card location chosen at that turn
  var timeStamp = {}; //timestamp for that turn
  //var indValues = new Array([0,1,2,3,4,5,6,7,8,9,10,11,12,                   13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35]);

  var Memory = {
    init: function(cards) {
      switch (manip) {
        case "sh":
          cards = cards.slice(0, 18);
       //   console.log(cards)
          //          cards = cards.shuffleCards;
          break;
        case "lo":
          //          cards = cards.slice(18, 18+nCards);
          cards = cards.slice(18, 36);
          break;
      }
      
      var i;
      for (i = 0; i < 18 - nCards; i++) {
        cards.splice(Math.floor(Math.random() * cards.length), 1);
      }
      this.$game = $(".game");
      this.$modal = $(".modal");
      this.$overlay = $(".modal-overlay");
      this.$restartButton = $("button.restart");
      this.cardsArray = $.merge(cards, cards);
      this.shuffleCards(this.cardsArray);
      this.setup();
    },

    // 		shuffles the cards
    shuffleCards: function(cardsArray) {
      this.$cards = $(this.shuffle(this.cardsArray));
    },

    // 		starts the game
    setup: function() {
      this.html = this.buildHTML();
      this.$game.html(this.html);
      this.$memoryCards = $(".card");
      this.paused = false;
      this.guess = null;
      this.binding();
    },

    // instructions for how to handle a "move" in the game
    binding: function() {
      this.$memoryCards.on("click", this.cardClicked);
      this.$restartButton.on("click", $.proxy(this.reset, this));
    },

    // kinda messy but hey
    cardClicked: function() {
      moves = moves + 1;
      var _ = Memory;
      var $card = $(this);
      turnN[moves] = moves; //stores move number
      turnID[moves] = $card.attr("data-id"); //stores card chosen
      turnLoc[moves] = $card.attr("loc"); //stores location chosen
      var date = new Date();
      timeStamp[moves] = date.getTime(); //stores timestamp

      if (
        !_.paused &&
        !$card.find(".inside").hasClass("matched") &&
        !$card.find(".inside").hasClass("picked")
      ) {
        $card.find(".inside").addClass("picked");
        if (!_.guess) {
          _.guess = $(this).attr("data-id");
        } else if (
          _.guess == $(this).attr("data-id") &&
          !$(this).hasClass("picked")
        ) {
          $(".picked").addClass("matched");
          _.guess = null;
        } else {
          _.guess = null;
          _.paused = true;
          setTimeout(function() {
            $(".picked").removeClass("picked");
            Memory.paused = false;
          }, 800);
        }
        if ($(".matched").length == $(".card").length) {
          _.win();
        }
      }
    },

    // 		if the game is over
    win: function() {
      var dataPlace = document.getElementsByClassName("full-game-data")[0];
      var usrMessage = document.getElementsByClassName("message")[0];
      var restartButton = document.getElementsByClassName("restart")[0];

      //Save stuff
      var turns = {
        n: turnN,
        id: turnID,
        loc: turnLoc,
        time: timeStamp,
        compCode: completeID,
        totMoves: moves,
        mgVersion: mgVersion
      };

      this.saveData(turns);

      //         console.log(trialCounter);
      //   console.log(nTrials);

      if (trialCounter == nTrials) {
        //all done
        dataPlace.textContent = completeID;
        usrMessage.textContent =
          `All done. Please copy the completion code below and return to the survey.`;
        restartButton.style.display = "none";
      } else {
        //go again
        usrMessage.textContent =
          `${trialCounter} down, ${nTrials-trialCounter} to go. Press the button below when you are ready to play another round.`;
        trialCounter = trialCounter + 1;
      }

      this.paused = true;
      setTimeout(function() {
        Memory.showModal();
        Memory.$game.fadeOut();
      }, 1000);
    },

    // 		box that celebrates the win
    showModal: function() {
      this.$overlay.show();
      this.$modal.fadeIn("slow");
    },

    // 		removes the win box
    hideModal: function() {
      this.$overlay.hide();
      this.$modal.hide();
    },

    // 		resets the game
    reset: function() {
      this.hideModal();
      this.shuffleCards(this.cardsArray);
      this.setup();
      this.$game.show("slow");
      moves = 0; // a counter of moves
      locations = ""; //locations of cards
      turnN = {}; //turn id
      turnID = {}; //card id chosen at that turn
      turnLoc = {}; //card location chosen at that turn
      timeStamp = {}; //timestamp for that turn
    },

    // 		algorithm that does the shuffling
    shuffle: function(array) {
      var counter = array.length,
        temp,
        index;

      // While there are elements in the array
      while (counter > 0) {
        // Pick a random index
        index = Math.floor(Math.random() * counter);
        // Decrease counter by 1
        counter--;
        // And swap the last element with it
        temp = array[counter];
        array[counter] = array[index];
        array[index] = temp;
      }
      return array;
    },

    saveData: function(turns) {
      const now = new Date();

      var idOrd = "";
      var locOrd = "";
      var nOrd = "";
      var timeOrd = "";
      for (var j = 1; j < moves + 1; j++) {
        idOrd += turns.id[j] + ",";
        locOrd += turns.loc[j] + ",";
        nOrd += turns.n[j] + ",";
        timeOrd += turns.time[j] + ",";
      }
      idOrd = idOrd.slice(0, -1);
      locOrd = locOrd.slice(0, -1);
      nOrd = nOrd.slice(0, -1);
      timeOrd = timeOrd.slice(0, -1);

      var url = "https://sheet2api.com/v1/U37G9Dp4Toq0/sheetsutest"; //this is my spreadsheet
      const newRowData = {
        Date: now,
        IPAddress: ipAddress,
        wWidth: windowWidth,
        wHeight: windowHeight,
        VersionKey: turns.mgVersion,
        Condition: manip,
        stimType: stimCondition,
        numCards: nCards,
        CompletionCode: turns.compCode,
        GameNum: trialCounter,
        GameTot: nTrials,
        Moves: turns.totMoves,
        TurnsID: nOrd,
        CardID: idOrd,
        LocationID: locOrd,
        TimeID: timeOrd
      };
      const options = {};
      Sheet2API.write(url, options, newRowData).then(
        function(result) {
          console.log(result);
        },
        function(error) {
          console.log(error);
        }
      );
    },

    buildHTML: function() {
      var frag = "";

      //      IMAGES VS. TEXT
      this.$cards.each(function(k, v) {
        switch (stimCondition) {
          case "i":
            frag +=
              '<div class="card" loc="' +
              (k + 1) +
              '" data-id="' +
              v.id +
              '"><div class="inside"><div class="front"><img src="' +
              v.img +
              '"alt="' +
              v.name +
              '" /></div><div class="back"></div><div class="back"><img src="https://openclipart.org/download/22144/Steren-Futurist-circle.svg"alt="Codepen" /></div></div></div>';
            break;
          case "w":
            frag +=
              '<div class="card" loc="' +
              (k + 1) +
              '" data-id="' +
              v.id +
              '"><div class="inside"><div class="front"><p style="font-size:30px">' +
              v.name +
              '</p></div><div class="back"></div><div class="back"><img src="https://openclipart.org/download/22144/Steren-Futurist-circle.svg"alt="Codepen" /></div></div></div>';
            break;
          default:
            "Error";
        }
        locations = locations + v.id;
      });

      return frag;
    }
  };

  var cards = [
    {
      name: "bagel",
      img: "/images/Bagel.png",
      id: 1
    },
    {
      name: "bowl",
      img: "/images/Bowl.png",
      id: 2
    },
    {
      name: "clip",
      img: "/images/Clip.png",
      id: 3
    },
    {
      name: "comb",
      img: "/images/Comb.png",
      id: 4
    },
    {
      name: "dart",
      img: "/images/Dart.png",
      id: 5
    },
    {
      name: "dice",
      img: "/images/Dice.png",
      id: 6
    },
    {
      name: "eggs",
      img: "/images/Eggs.png",
      id: 7
    },
    {
      name: "lock",
      img: "/images/Lock.png",
      id: 8
    },
    {
      name: "mouse",
      img: "/images/Mouse.png",
      id: 9
    },
    {
      name: "pear",
      img: "/images/Pear.png",
      id: 10
    },
    {
      name: "pills",
      img: "/images/Pills.png",
      id: 11
    },

    {
      name: "razor",
      img: "/images/Razor.png",
      id: 12
    },
    {
      name: "ruler",
      img: "/images/Ruler.png",
      id: 13
    },
    {
      name: "saw",
      img: "/images/Saw.png",
      id: 14
    },
    {
      name: "stamp",
      img: "/images/Stamp.png",
      id: 15
    },
    {
      name: "watch",
      img: "/images/Watch.png",
      id: 16
    },
    {
      name: "yarn",
      img: "/images/Yarn.png",
      id: 17
    },
    {
      name: "yo-yo",
      img: "/images/Yoyo.png",
      id: 18
    },
    {
      name: "broccoli",
      img: "/images/Broccoli.png",
      id: 19
    },
    {
      name: "calculator",
      img: "/images/Calculator.png",
      id: 20
    },
    {
      name: "chocolate",
      img: "/images/Chocolate.png",
      id: 21
    },
    {
      name: "cigarette",
      img: "/images/Cigarette.png",
      id: 22
    },
    {
      name: "clipboard",
      img: "/images/Clipboard.png",
      id: 23
    },
    {
      name: "crackers",
      img: "/images/Crackers.png",
      id: 24
    },
    {
      name: "earrings",
      img: "/images/Earrings.png",
      id: 25
    },
    {
      name: "flashlight",
      img: "/images/Flashlight.png",
      id: 26
    },
    {
      name: "harmonica",
      img: "/images/Harmonica.png",
      id: 27
    },
    {
      name: "lipstick",
      img: "/images/Lipstick.png",
      id: 28
    },
    {
      name: "microphone",
      img: "/images/Microphone.png",
      id: 29
    },
    {
      name: "scissors",
      img: "/images/Scissors.png",
      id: 30
    },
    {
      name: "screwdriver",
      img: "/images/Screwdriver.png",
      id: 31
    },
    {
      name: "toothbrush",
      img: "/images/Toothbrush.png",
      id: 32
    },
    {
      name: "toy truck",
      img: "/images/ToyTruck.png",
      id: 33
    },
    {
      name: "umbrella",
      img: "/images/Umbrella.png",
      id: 34
    },
    {
      name: "watermelon",
      img: "/images/Watermelon.png",
      id: 35
    },
    {
      name: "wooden fork",
      img: "/images/WoodenFork.png",
      id: 36
    }
  ];

  function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
  }

  Memory.init(cards);
})();
